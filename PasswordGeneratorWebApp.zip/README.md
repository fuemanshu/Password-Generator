# Password Generator
Password Generator App


This app generates a random password using a combination of characters from numbers, letters, and special characters.

Stack
- HTML
- Java Script

090225
Currently in Brainstorm Phase

090325
App is at MVP 1.0
- Accepts User Input, creates an array, generates random password and displays on the application and console.

- Characters for random password are in the "availableCharacters" variable in the script in the Index.html file. Make a change to these characters if you want to use different characters. I plan to add options to include/exlude certain characters based on user need.

090525
- Password Generator Web App Zip file added for non develops to use/test
- Directions
    - Download Zip File
    - extract files
    - open "index.html" file in a web browser
    - enter your password length
    - click "Generate Password" button

Developer Ending Statement - Any questions or comments please let me know. Use at your own Peril....